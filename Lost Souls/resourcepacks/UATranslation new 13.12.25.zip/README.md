# UA-Translation
<p>Credits: <a href="https://github.com/CakesTwix">@CakesTwix</a> <a href="https://github.com/ICHTLAY">@ICHTLAY <a href="https://github.com/hnufelka">@hnufelka</a> Sinqoire <a href="https://github.com/SKZGx">@SKZGx </a><a href=https://github.com/Tapio-adro">@Tapio-adro</a></p><br><br>
<p align="center">
  <img src="https://i.imgur.com/f5TjzbQ.png" alt="logo" style="width:300px;height:300px;>
</p>
 
<br><br>


<p align="justify"><br><br>👋 Привіт, СУМ-ки! 🌟

Ми з радістю представляємо наш новий ресурс пак, який додає українську мову до наступних модів Minecraft: Apotheosis 🌟, Create Addition 🛠️, Gobber2 ⚔️, Immersive Engineering 🔩, Spice of Life: Sweet Potato Edition 🍠, End's Delight 🌋, Framed Compacting Drawers 🗄️, Frozen Delight ❄️, Frozen Up 🥶, Ore Excavation ⛏️, Rotten Creatures 🧟‍♂️, Nether's Exoticism 🌡️, Nether's Delight 🌶️, Nether's Cruelty 🔥, The One Probe 🔍, та StorageDrawers 🗃️ тощо.

Наша спільнота Українізації Модів (СУМ) пильно працювала над цим проєктом, щоб зробити Minecraft ще більш доступним для української спільноти гравців. Тепер ви зможете насолоджуватися грою на державній мові, не втрачаючи жодної деталі геймплею.

Ми просимо нашу спільноту внести свій вклад у розвиток цього проєкту, адже разом ми зможемо зробити Minecraft ще більш привабливим для гравців української мови. Приєднуйтеся до нас в телеґрам(https://t.me/SUMTranslate), слідкуте та долучайтеся до перекладу нових модів! 💪

Через посилання на проєкти "crowdin" 🌐 можна буде долучитись до перекладу популярних модів(або не дуже). 💻🎮
Також можна запропонувати мод на переклад.

Дякуємо за вашу підтримку та інтерес до нашого проєкту!

<i>PS зараз це перекладається і додається до проектів через Pull`и, але якщо хтось з розробників хоче, завжди можете звертатись до нас (пошта в кінці).</i>
</p>
<a href="https://discord.gg/RBuQk37xr8"><br><br>
<img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white">
</a>
<a href="">
<img src="https://img.shields.io/badge/Minecraft-000000?style=for-the-badge&logo=minecraft&logoColor=white">
</a>
<p>
<br><br><br><br><br><center><p align="center">
The full list of mod translations is available on the website<br>
Повний список перекладів модів можна переглянути на сайті<br>
<a href="https://sumtranslate.netlify.app/">https://sumtranslate.netlify.app/</a></p>

<img align="center" style="width:100%;align:center;" src="https://i.imgur.com/C5KSQsx.jpg"><br><br><br></center>
👋 Hello!

We are pleased to present our new resource pack, which adds the Ukrainian language to the following Minecraft mods: Apotheosis 🌟, Create Addition 🛠️, Gobber2 ⚔️, Immersive Engineering 🔩, Spice of Life: Sweet Potato Edition 🍠, End's Delight 🌋, Framed Compacting Drawers 🗄️, Frozen Delight ❄️, Frozen Up 🥶, Ore Excavation ⛏️, Rotten Creatures 🧟‍♂️, Nether's Exoticism 🌡️, Nether's Delight 🌶️, Nether's Cruelty 🔥, The One Probe 🔍, and StorageDrawers 🗃️ etc.

Our Ukrainianisation of Mods (UOM) community has been working hard on this project to make Minecraft even more accessible to the Ukrainian player community. Now you can enjoy the game in the state language without missing a single gameplay detail.

We are asking our community to contribute to the development of this project, as together we can make Minecraft even more attractive to Ukrainian players. Join us in the telegram (https://t.me/SUMTranslate), follow us, and join the translation of new mods 💪

You can join the translation of popular mods (or not) through the links to the "crowdin" projects 🌐. 💻🎮
You can also suggest a mod for translation.
Thank you for your support and interest in our project!

<i>This is currently being translated and added to projects through Pulls, but if any of the developers want to, you can always contact us (email at the end).</i>
</p>





<br/>* 👯 I’m looking to collaborate on everyone
<br/>* 💬 Ask me about translate ur mod
<br/>* 📫 How to reach me: megatrex4@yahoo.com

